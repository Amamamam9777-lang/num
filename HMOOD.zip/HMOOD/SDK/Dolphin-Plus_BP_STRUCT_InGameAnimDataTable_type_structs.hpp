#pragma once

// WE SUPPORT FUN  (4.7.0) SDKGen by @Dolphin-Plus | @T4_Q3 
// Send Message Me For SDKGen Tool  
// Generate on Thu Nov 12 21:01:43 2026
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_InGameAnimDataTable_type.BP_STRUCT_InGameAnimDataTable_type
// 0x0028
struct FBP_STRUCT_InGameAnimDataTable_type
{
	struct FString                                     DataAssetPath_0_7567ED4043E2B0F327760459069E5168;         // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_4C8A2EC037ED27350FAD135A0DD61684;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Type_2_5C2554002D07C8607FED57B20617FDB5;                  // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     SharedIdGroupStr_3_20943E002C0AB39A2E94769F07C36102;      // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

