#pragma once

// WE SUPPORT FUN  (4.7.0) SDKGen by @Dolphin-Plus | @T4_Q3 
// Send Message Me For SDKGen Tool  
// Generate on Thu Nov 12 21:01:43 2026
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_LevelUnLockAnimConfig_type.BP_STRUCT_LevelUnLockAnimConfig_type
// 0x003C
struct FBP_STRUCT_LevelUnLockAnimConfig_type
{
	struct FString                                     AnimTargetOffset_0_6979A2002475EDFE470D79C20FBB2FC4;      // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     AnimTargetUIConfig_1_32F425406D740B4F300BF26C0A744387;    // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     AnimTargetWidget_2_68CBE1407FA7EC076639EF3F0F385BC4;      // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_3_5305B08075A4B66E4665B91D0F444FC4;                    // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                LobbyType_4_0B3E13C013D720F14799826F0CDBC4C5;             // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                SystemID_5_101131C01C105D75320550F40FEF0F14;              // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

